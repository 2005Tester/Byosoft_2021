from _typeshed import Incomplete

class _GlobalCfg:
    ver: str

class Sut:
    BIOS_COM: Incomplete
    BMC_COM: Incomplete
    BMC_SSH: Incomplete
    BMC_SFTP: Incomplete
    BMC_RFISH: Incomplete
    OS_SSH: Incomplete
    OS_SFTP: Incomplete
    OS_LEGACY_SSH: Incomplete
    OS_LEGACY_SFTP: Incomplete
    UNITOOL: Incomplete
    UNITOOL_LEGACY_OS: Incomplete

class ProjectInit:
    cli: Incomplete
    prjcfg_file: str
    project_list: Incomplete
    def __init__(self, cliparser) -> None: ...
    def load_project(self): ...

class SutInit:
    sut: Incomplete
    resources: Incomplete
    def __init__(self, project, resources) -> None: ...
