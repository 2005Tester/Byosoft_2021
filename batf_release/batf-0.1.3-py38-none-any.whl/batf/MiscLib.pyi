def ping_sut(ip: str, timeout: int) -> bool:
    """
    Ping the ip address until timeout

    Parameters
    ----------
    ip: str
        IP address
    timeout: int
        if ping timeout, process will be break

    Returns
    -------
    True:   ip is connected
    False:  ip is not connected and ping timeout
    """
def verify_msgs_in_log(msg_list: list, captured_log: str):
    """
    Verify if all the messages list in the log,  with regex match

    Parameters
    ----------
    msg_list: list
        The list contains all the strings to be verified
    captured_log: str
        The log strings of captured

    Returns
    -------
    True:   All members in the msg_list in the capture_log
    False:  At least one of the members not in the capture_log
    """
def uncompress_targz(targz_file: str, uncom_path: str):
    """
    Extract all files in the tar.gz package to specific path

    Parameters
    ----------
    targz_file: str     The tar.gz file path.
    uncom_path  str     The path that files will be extract to.

    Returns
    -------
    str:        return the uncompress path if extract files success
    False:      return False if uncompress failed
    """
def compare_images(image1: str, image2: str, image_diff: str = ...) -> bool:
    """
    compare whether two images are the same.

    Parameters
    ----------
    image1 : str
        File path of the 1st image to be compared.
    image2 : str
        File path of the 2nd image to be compared.
    image_diff: str
        save the difference as a picture if not same

    Returns
    -------
    Bool
    return True if they are same, otherwise return false
    """
def same_values(item_a: list, item_b: list):
    """
    Check if two list object contains the same members and ignore the order

    Parameters
    ----------
    item_a: list    The 1st list to be checked
    item_b: list    The 2nd list to be checked

    Returns
    -------
    True:   The two list members are same
    False:  The two list members are different
    """
