from _typeshed import Incomplete

class DingTalkRobot:
    report: Incomplete
    sign: Incomplete
    base_url: Incomplete
    def __init__(self, base_url, url_report, signature) -> None:
        """
        """
    def gen_url(self):
        """
        """
    def send_msg(self, tittle, description) -> None:
        """
        """
