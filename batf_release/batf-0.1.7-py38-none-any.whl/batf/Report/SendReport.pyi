from _typeshed import Incomplete

class EmailReport:
    smtpserver: Incomplete
    sender: Incomplete
    receiver: Incomplete
    pw: Incomplete
    def __init__(self, smtpserver, sender, receiver, pw, _subtype: str = ...) -> None:
        """
        """
    def send_mail(self, html_report, attachment) -> None:
        """
        """
