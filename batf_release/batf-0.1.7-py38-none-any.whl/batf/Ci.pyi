from _typeshed import Incomplete

class Gitlab:
    projectid: Incomplete
    access_token: Incomplete
    base_url: str
    header: Incomplete
    jobs_url: Incomplete
    def __init__(self, projectid, access_token) -> None:
        """
        """
    def get_all_jobs(self):
        """
        """
    def get_latest_job(self, branch, jobname: Incomplete | None = ...):
        """
        """
    @staticmethod
    def print_msg(job) -> None:
        """
        """
    def download_image(self, job, dir, img_name):
        """
        """
    def download_latest_image_master(self, dir, img_name):
        """
        """
    def download_latest_image(self, branch, dir, img_name, jobname: Incomplete | None = ...):
        """
        """
    @staticmethod
    def unzip(artifacts, dst, img_name):
        """
        """
