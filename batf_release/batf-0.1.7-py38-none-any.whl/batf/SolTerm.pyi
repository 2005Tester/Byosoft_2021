from _typeshed import Incomplete
from batf.BiosSetup import TermParser
from batf.Common.ssh import SshConnection
from paramiko.channel import Channel as Channel
from typing import Union

class SolTerm(SshConnection, TermParser):
    data: str
    logfile: Incomplete
    key: Incomplete
    sol_session: Incomplete
    def __init__(self, host_ip, username, password, logfile: Incomplete | None = ..., key=...) -> None:
        """
        """
    def is_ssh_active(self):
        """
        """
    def is_sol_active(self):
        """
        """
    def open_sol(self, cmd: str = ...):
        """
        """
    def close_sol(self):
        """
        """
    def write_data(self, data, delay: Union[int, float] = ...):
        """
        """
    def send_data(self, data, delay: Union[int, float] = ...):
        """
        """
    def send_a_key(self, key, delay: Union[int, float] = ...):
        """
        """
    def send_multi_keys(self, keys: list, delay: Union[int, float] = ...):
        """
        """
    def read_data(self, size: int = ...):
        """
        """
    def wait_msgs(self, msgs, timeout: int = ...):
        """
        """
    def set_logfile(self, logfile: str):
        """
        Set path and name for saving file
        """
    password: Incomplete
    pw_prompt: Incomplete
    def set_password(self, password, pw_prompt) -> None:
        """
        Set BIOS login password if required
        Parameters
        ----------
        password:       str:    BIOS login password
        pw_prompt:      str:    BIOS login prompt message, this determin when to input the password

        Returns
        -------
        None
        """
    @staticmethod
    def is_timeout(t_start, timeout):
        """
        """
    @staticmethod
    def find_msg(msg, data, exact: bool = ..., echo: bool = ...):
        """
        """
    def clean_buffer(self) -> None:
        """
        """
    def check_log_path(self):
        """
        """
    def write_data2log(self, data: str):
        """
        """
    def capture_data(self, timeout: int = ..., save: bool = ..., echo: bool = ..., clean: bool = ...):
        """
        """
    def read_full_buffer(self, delay: int = ..., timeout: int = ..., save: bool = ...):
        """
        Read a section of full strings in the buffer, to avoid output strings been split up.
        Parameters
        ----------
        delay: int      Exit if buffer is empty after wait a delay
        timeout: int    Exit unconditionally after wait a timeout
        save: bool      Choose if the data need to save

        Returns
        -------
        str             return strings in buffer
        """
    def is_msg_present_general(self, msgs: Union[str, list], timeout, pw_prompt: Incomplete | None = ..., pw: Incomplete | None = ..., cleanup: bool = ...):
        """
        Wait messages in the accumulated buffer to avoid strings split.
        Support one or more msgs, even 2 consecutive lines.
        Note: Automatic login if password prompt is found.
        Parameters
        ----------
        msgs:           str/list:   msg strings or msgs list for wait.
        timeout:        int:        timeout to break in nothing found
        pw_prompt:      str:        password prompt msg for user login
        pw:             str:        password for user login
        cleanup:        bool        choose if clean the serial output

        Returns
        -------
        bool:           Return True if found the message within the time
        """
    def is_msg_not_present(self, msg: str, end_flag: str, timeout: int):
        """
        Verify specified message (msg1) should not appear in serial logfile, but except_msg should be present
        Parameters
        ----------
        msg:            str:    message should not appear until end_flag
        end_flag:       str:    message should be present and will stop waiting if end_flag appear
        timeout:        int:    timeout to break

        Returns
        -------
        bool        Return True if msg1 not appear, and except_msg present
        """
    def boot_with_hotkey(self, hotkey, confirm: str, timeout, prompt: str, pw_prompt: Incomplete | None = ..., pw: Incomplete | None = ..., retry: int = ...):
        """
        Send the hotkey if hotkey prompt appear, then wait the confirm msg appeared
        Parameters
        ----------
        hotkey:         list:   Key to press
        confirm:        str:    Message to confirm press hotkey is success
        timeout:        int:    Timeout to break in nothing found
        prompt:         str:    strings appear when to press the hotkey
        pw_prompt:      str:    password prompt msg for user login
        pw:             str:    password for user login
        retry:          int:    retry counts to send the hotkey at the prompt message

        Returns
        -------
        bool:           Return True if msg found after press the hotkey at {hotkey_prompt} appear.
        """
    def navigate_and_verify(self, key, options, try_counts: int):
        """
        Press the key continuous, and verify whether specific strings present, or ["name", "value"] pair present.
        Parameters
        ----------
        key:            list:   Key to press
        options:        list:   msgs to verify,
                                    type1:  string list -- ["name1", "name2"]
                                    type2:  pair list -- [["name1", "value1"], ["name2", "value2"]]
        try_counts:     int:    Key press count

        Returns
        -------
        bool:           return True if all strings present after key pressed
        """
    def locate_option(self, key, name: str, value: str = ..., counts: int = ..., delay: float = ..., order: int = ..., span: Incomplete | None = ..., exact: bool = ...):
        """
        Locate to the setup option or menu name, stop there if locate success, name support regular match
        Parameters
        ----------
        key:            list:       Key to press
        name:           str:        Setup option name
        value:          str:        Confirm option value if set
        counts:         int:        Key press count
        delay:          int:        delay time after key pressed
        order:          int:        Specific the option order if there are multi options with the same name in one page.
        span:           int:        Specific the row span of the option. if not set, will be auto calculated.
        exact:          bool:       if True, match the option name/value with fullmatch, otherwise search


        Returns
        -------
        bool:           If both name and value given, return True if all found.
                        If only name is given, return True if option name is found.
        """
    def locate_menu(self, key, name: str, try_limits: int = ..., exact: bool = ...):
        """
        Locate to the menu and stop there, name support regular match
        Parameters
        ----------
        key:            list:   Key to press
        name:           str:    Menu name need locate to
        try_limits:     int:    Key press count
        exact:          bool:   if True, match the option name/value with fullmatch, otherwise search

        Returns
        -------
        bool:           return True if locate to the specific menu success
        """
    def enter_menu(self, key, menu_path: list, try_counts: int = ..., confirm: str = ..., timeout: int = ..., exact: bool = ...):
        """
        Enter the specific setup menu by given path(list)
        """
    def get_option_value(self, option, value, key, try_limits: int = ..., delay: float = ..., order: int = ..., span: Incomplete | None = ..., exact: bool = ...):
        """
        navigate and get setup option value by name
        """
    def cut_log(self, start: str, end: str, duration: int = ..., timeout: int = ..., last: bool = ...) -> str:
        """
        Cut a section of serial log from {start} to {end}
        Parameters
        ----------
        start: str  if start flag is found, start to capture the serial log
        end: str    if end flag is found, return
        duration:   if start flag is found, wait the seconds of "duration" to return, even end flag is not found
        timeout:    if start not found or end not found in specific seconds, return
        last: bool  cut from the last "start" msg, else from the 1st "start" msg

        Returns
        -------
        str:        return the strings of cut. if start not found, return ""
        """
    def get_value_list(self, try_limits: int = ...):
        """
        """
    def get_supported_values_long(self, key_count: int):
        """
        """
    def locate_value(self, value: str, try_limits: int = ...):
        """
        locate to the target value, need locate to the target option first
        value_str: the target value to highlight
        """
    def get_grey_option(self, option: Union[str, list, dict], key, counts: int = ..., refresh_keys: list = ...):
        """
        Get pairs of grey out {options: value}
        Attention:
            1. Grey out options can't be located, so they will only appear once when terminal refresh.
            2. If the grey out option not appear, try to continue press key to make the page refresh.
        Parameters
        ----------
        option:         str         if just check option is grey out and value don't care, input the option name str
                        list        if need check one more options are grey out and values don't care, input the option names list
                        dict        if need check option is grey out and confirm the value, input the {option1: value1, ...}

        key:            str/list    key to press for serial output refresh
        counts:         int         max times of key pressed
        refresh_keys:    list        press special keys to make the page refresh when need: [ESC, ENTER] or [LEFT, RIGHT]

        Returns
        -------
        dict:                   dict like: {option1: value1, option2: value2, ....}
        """
