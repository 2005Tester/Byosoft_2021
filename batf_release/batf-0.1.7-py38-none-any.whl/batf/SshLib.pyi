from _typeshed import Incomplete

def execute_command(ssh: object, command: str, print_result: bool = ...):
    """
    Run a command via ssh connection. "
    " is not required

    Parameters
    ----------
    ssh : object
        object of ssh connection, for example: Sut.BMC_SSH
    command : str
        command to be executed on remote system.
    print_result : bool
        whether print out execution result to console and log, default is false.

    Returns
    -------
    Str: Text returned from remote system after command is executed, could be none if nothing is returned.
    """
def interaction(ssh: object, commands: list, rets: list, timeout: int = ..., delay: int = ...):
    """
    Run a list of commands via ssh connection, and check whether each of them is successful. "
    " is required for each command.

    Parameters
    ----------
    ssh : object 
        object of ssh connection, for example: Sut.BMC_SSH
    commands : list
        List of commands to be executed on remote system.
    rets : list
        Expected result for each commands, 1:1 mapping with commands parameter.
    timeout : int
        Timeout value to wait for result after a command is executed.
    delay :  int
        Delay time after each cmd is send.

    Returns
    -------
    bool: 
        Return true if each of command returns expected result, otherwise return false.
    """
def dump_info(ssh, command, log_dir, log_name: Incomplete | None = ...): ...
def check_diff(ssh, command, lkg): ...
def verify_info(ssh, command, infos): ...
def sftp_remove_file(sftp: object, file_re: str, dir: str = ...) -> None:
    """
    Remove a file from sftp, file name matches file_re, support regular expression.

    Parameters
    ----------
    sftp : object 
        object of sftp connection, for example: Sut.BMC_SFTP
    file_re : str
        File name or patten of file name to be removed.
    dir : str
        Directory of the file to be removed, default is root of sftp login.

    Returns
    -------
    None:
    """
def sftp_upload_file(sftp, src_file, dst_file, ret_msg: str = ...): ...
def sftp_download_file(sftp, src_file, dst_file): ...
def sftp_lsdir(sftp: object, dir: str = ...):
    """
    List files and directories of a remote directory.

    Parameters
    ----------
    sftp : object 
        object of sftp connection, for example: Sut.BMC_SFTP
    dir : str
        Target directory, default is root of sftp login.

    Returns
    -------
    str:
        Return the files and directories of the atrget dir.
    """
