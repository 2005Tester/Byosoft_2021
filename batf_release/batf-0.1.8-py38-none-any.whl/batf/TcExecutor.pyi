from _typeshed import Incomplete

class CliParse:
    project: Incomplete
    execution_type: Incomplete
    sut_name: Incomplete
    post: Incomplete
    trace: bool
    scope: Incomplete
    def __init__(self) -> None:
        """
        """
    def get_project(self):
        """
        """
    def get_sutname(self):
        """
        """
    def get_execution_type(self):
        """
        """
    def get_post(self):
        """
        """
    def get_test_scope(self):
        """
        """

class RunTest:
    config: Incomplete
    script: Incomplete
    execution_type: Incomplete
    post: Incomplete
    trace: Incomplete
    logdir: Incomplete
    def __init__(self, config, script, execution_type, post: Incomplete | None = ..., trace: Incomplete | None = ...) -> None:
        """
        """
    def init_log(self):
        """
        """
    def gen_report(self, log_dir) -> None:
        """
        """
    def run(self) -> None:
        """
        """

EXEC_TYPE: Incomplete
TC_GROUP: Incomplete

class TestScope:
    project: Incomplete
    csv_file: Incomplete
    execution_type: Incomplete
    default: Incomplete
    legacy: Incomplete
    os: Incomplete
    equip: Incomplete
    fulldebug: Incomplete
    all_tc: Incomplete
    tc_to_run: Incomplete
    csv_errs: Incomplete
    def __init__(self, csv_file, execution_type) -> None:
        """
        """
    def check_csv(self) -> None:
        """
        """
    def run_test(self, category) -> None:
        """
        """
