from typing import Any

class EmailReport:
    smtpserver: Any
    sender: Any
    receiver: Any
    pw: Any
    def __init__(self, smtpserver, sender, receiver, pw, _subtype: str = ...) -> None: ...
    def send_mail(self, html_report, attachment) -> None: ...
