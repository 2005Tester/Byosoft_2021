from typing import Any

STD_INPUT_HANDLE: int
STD_OUTPUT_HANDLE: int
STD_ERROR_HANDLE: int
FOREGROUND_BLACK: int
FOREGROUND_BLUE: int
FOREGROUND_GREEN: int
FOREGROUND_RED: int
FOREGROUND_INTENSITY: int
BACKGROUND_BLUE: int
BACKGROUND_GREEN: int
BACKGROUND_RED: int
BACKGROUND_INTENSITY: int

class PrintColor:
    std_out_handle: Any
    def set_cmd_color(self, color, handle=...): ...
    def reset_color(self) -> None: ...
    def print_red_text(self, print_text) -> None: ...
    def print_green_text(self, print_text) -> None: ...
    def print_blue_text(self, print_text) -> None: ...
    def print_red_text_with_blue_bg(self, print_text) -> None: ...
