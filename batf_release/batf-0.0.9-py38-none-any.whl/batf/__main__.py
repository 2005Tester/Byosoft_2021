import sys
from batf import SutInit
from batf import TcExecutor
from batf import var
from batf.SutInit import _GlobalCfg


def console_entry() -> None:
    print("Byosoft Automation Test Framework Version {0}".format(_GlobalCfg.ver))
    sys.path.append(".")
    cli = TcExecutor.CliParse()
    prj_init = SutInit.ProjectInit(cli)
    cfg, script, resources = prj_init.load_project()
    type = cli.get_execution_type()
    post_result = cli.get_post()
    test = TcExecutor.RunTest(cfg, script, type, post_result)
    SutInit.SutInit(var.get('project'), resources)
    test.run()


if __name__ == '__main__':
    console_entry()
