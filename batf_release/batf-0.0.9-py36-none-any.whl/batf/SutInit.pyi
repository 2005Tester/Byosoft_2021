from typing import Any

class _GlobalCfg:
    ver: str

class Sut:
    BIOS_COM: Any
    BMC_COM: Any
    BMC_SSH: Any
    BMC_SFTP: Any
    BMC_RFISH: Any
    OS_SSH: Any
    OS_SFTP: Any
    OS_LEGACY_SSH: Any
    OS_LEGACY_SFTP: Any
    UNITOOL: Any

class ProjectInit:
    cli: Any
    prjcfg_file: str
    project_list: Any
    def __init__(self, cliparser) -> None: ...
    def load_project(self): ...

class SutInit:
    sut: Any
    resources: Any
    def __init__(self, project, resources) -> None: ...
