from typing import Any

class CliParse:
    project: Any
    execution_type: Any
    sut_name: Any
    post: Any
    def __init__(self) -> None:
        """
        """
    def get_project(self):
        """
        """
    def get_sutname(self):
        """
        """
    def get_execution_type(self):
        """
        """
    def get_post(self):
        """
        """

class RunTest:
    config: Any
    script: Any
    execution_type: Any
    post: Any
    logdir: Any
    def __init__(self, config, script, execution_type, post: Any | None = ...) -> None:
        """
        """
    def init_log(self):
        """
        """
    def gen_report(self, log_dir) -> None:
        """
        """
    def run(self) -> None:
        """
        """

EXEC_TYPE: Any
TC_GROUP: Any

class TestScope:
    project: Any
    csv_file: Any
    execution_type: Any
    default: Any
    legacy: Any
    os: Any
    equip: Any
    fulldebug: Any
    all_tc: Any
    tc_to_run: Any
    csv_errs: Any
    def __init__(self, csv_file, execution_type) -> None:
        """
        """
    def check_csv(self) -> None:
        """
        """
    def run_test(self, category) -> None:
        """
        """
