from typing import Any

def execute_command(ssh: object, command: str):
    """
    Run a command via ssh connection.

    Parameters
    ----------
    ssh : object of ssh connection, for example: Sut.BMC_SSH
    command : command to be executed on remote system.

    Returns
    -------
    Str: Text returned from remote system after command is executed, could be none if nothing is returned.
    """
def interaction(ssh: object, commands: list, rets: list, timeout: int = ...):
    """
    Run a list of commands via ssh connection, and check whether each of them is successful.

    Parameters
    ----------
    ssh : object of ssh connection, for example: Sut.BMC_SSH
    command : command to be executed on remote system.

    Returns
    -------
    Str: Text returned from remote system after command is executed, could be none if nothing is returned.
    """
def dump_info(ssh, command, log_dir, log_name: Any | None = ...): ...
def check_diff(ssh, command, lkg): ...
def verify_info(ssh, command, infos): ...
def sftp_remove_file(sftp, file_re, dir: str = ...): ...
def sftp_upload_file(sftp, src_file, dst_file, ret_msg: Any | None = ...): ...
def sftp_download_file(sftp, src_file, dst_file): ...
def sftp_lsdir(sftp, dir: str = ...): ...
