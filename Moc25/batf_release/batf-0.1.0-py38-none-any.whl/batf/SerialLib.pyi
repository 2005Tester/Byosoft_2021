def is_msg_present(serial: object, msg: str, delay: int = ..., cleanup: bool = ...):
    """
    Check whether a message is present in serial read buffer.

    Parameters
    ----------
    serial : object of serial connection, for example: Sut.BIOS_COM
    msg : a message or a message patten to be matched in the serial read buffer
    delay: A timeout value to wait for the message
    cleanup: Whether to cleanup the escape sequence character


    Returns
    -------
    Bool
    Return true if message is matched, otherwise return false
    """
def is_msg_not_present(serial: object, msg1: str, msg2: str):
    """
    Check whether a message is present before another message apperas in the serial output.

    Parameters
    ----------
    serial : object of serial connection, for example: Sut.BIOS_COM
    msg1 : a message or a message patten to be matched in the serial read buffer
    msg2: if msg1 not found, while msg2 appears, exit method


    Returns
    -------
    Bool
    Return true if msg1 is matched before msg2 appears, otherwise return false
    """
def is_msg_list_present(serial: object, msg_list: list, delay: int = ...):
    """
    Check whether a list of messages are present in serial read buffer.

    Parameters
    ----------
    serial : object of serial connection, for example: Sut.BIOS_COM
    msg_list : a list of messages or patten to be matched in the serial read buffer
    delay: A timeout value to wait for the message

    Returns
    -------
    Bool
    Return true if messages are matched, otherwise return false
    """
def send_keys_with_delay(serial: object, keys: list, delay: int = ...):
    """
    Send keys to serial port one by one with customized delay.

    Parameters
    ----------
    serial : object of serial connection, for example: Sut.BIOS_COM
    keys : a list of keys to be sent to serial port, for example: [Key.UP, Key.UP, Key.ENTER]
    delay: delay in seconds before sending another key

    Returns
    -------
    None
    """
def send_key(serial: object, key):
    """
    Send a key to serial port.

    Parameters
    ----------
    serial : object of serial connection, for example: Sut.BIOS_COM
    key : a key defined in PlatConfig.py or SutCOnfig

    Returns
    -------
    None
    """
def run_command(serial, command, msg) -> None: ...
def send_data(serial, data) -> None: ...
def read_buffer(serial): ...
def recv_data(serial, size: int = ...): ...
def clean_buffer(serial) -> None: ...
def cut_log(serial: object, start_str: str, end_str: str, duration: int = ..., timeout: int = ...):
    """
    Cut text between start_str and end_str form serial output.

    Parameters
    ----------
    serial : object of serial connection, for example: Sut.BIOS_COM
    start_str : a flag to start capture the text
    end_str: a flag to end capture the text
    duration: Time to wait to stop captureing, if start_str found but end_str not found in the serial output
    timeout: timeout value of waiting the start_str

    Returns
    -------
    Text: Captured text from serial output.
    """
