from typing import Any

class Status:
    Pass: int
    Skip: int
    Fail: Any

def test_case(tc: tuple) -> None:
    """
    װ����, ���ڱ�ʶ��������.
    """
def capture_screen(img_dir: Any | None = ..., img_file: Any | None = ...) -> None:
    """
    Capture screen when needed, will try to call BMCLib to capture SUT KVM, if failed host based screen
    capture will be invoked. Captured image will be saved in test log directory by default.
    To Enable Screen capture by BMC, method capture_kvm_screen(dir, filename) must be implimented in
    BaseLib.BmcLib, expect return True if image is captured successfully.
    """
def stylelog(text: str, type: str) -> None:
    """
    Add clored style in logging message of html report, to highlight some checkpoints in test.

    Parameters
    ----------
    text : str
        Message to be highlighted.
    type : str
        Type of the message, 4 types are supported, 'fail', 'success', 'warning', 'info'.
        fail: show red text in html report.
        success: show green text in html report.
        warning: show yellow text in html report.
        info: show blue text in html report.

    Returns
    -------
    None
    """
