from selenium.common.exceptions import NoSuchWindowException as NoSuchWindowException
from selenium.webdriver.common.alert import Alert as Alert
from selenium.webdriver.remote.webdriver import WebDriver as WebDriver, WebElement as WebElement
from typing import Any, List, Union

LOCATE_BY: Any

class Chrome:
    driver: Any
    interval: Any
    options: Any
    download_dir: Any
    locate_by: Any
    imp_wait: Any
    browser: Any
    def __init__(self, driver_path: str, interval: Union[int, float] = ..., imp_wait: Union[int, float] = ...) -> None:
        """
        Locate the web elements with Chrome Browser for automation web control.
        8 types shot names of element location methods are provided, General methods is also supported:
            "id"    :   By.ID,
            "xpath" :   By.XPATH,
            "link"  :   By.LINK_TEXT,
            "plink" :   By.PARTIAL_LINK_TEXT,
            "name"  :   By.NAME,
            "tag"   :   By.TAG_NAME,
            "class" :   By.CLASS_NAME,
            "css"   :   By.CSS_SELECTOR,

        Parameters
        ----------
        driver_path:    The path of chromedriver
        interval:       The delay time of each operation, default is 0.5s
        imp_wait:       The implicitly_wait time, default is 5s
        """
    def set_download_path(self, path: str) -> None:
        """
        Modify the default chrome download directory
        """
    def open_page(self, url: str) -> bool:
        """
        Open the page in a new window
        """
    def new_page(self, url: str) -> bool:
        """
        Open the page in the exists window
        """
    def max_window(self) -> None:
        """
        Maximize the window
        """
    temp_interval: Any
    def set_delay(self, delay: Union[int, float, None] = ...):
        """
        某些页面元素不需要等待，加快定位速度
        """
    def set_impwait(self, imp_wait):
        """
        """
    def wait_element_not_exist(self, by, element, timeout: int = ...):
        """
        """
    def element_exist(self, by: str, element: str) -> Union[WebElement, List[WebElement]]:
        """
        Check if the element exists
        """
    def find_element(self, by: str, element: str, name: str = ...) -> Union[WebElement, List[WebElement]]:
        """
        Find the element
        Parameters
        ----------
        name:       Specific the element name for pretty logging

        Returns
        -------
        WebElement
        """
    def move_to_element(self, by: str, element: str, name: str = ...) -> bool:
        """
        Move to the element
        Parameters
        ----------
        name:          Specific the element name for pretty logging

        Returns
        -------
        """
    def click_element(self, by: str, element: str, name: str = ...) -> bool:
        """
        Click the element
        Parameters
        ----------
        name:       Specific the element name for pretty logging

        Returns
        -------
        True:       element found
        None:       element not found
        """
    def send_element(self, by: str, element: str, value: str, name: str = ...) -> bool:
        """
        Send some text to the element
        Parameters
        ----------
        value:      The text input to the element
        name:       Specific the element name for pretty logging

        Returns
        -------
        True:       element found
        None:       element not found
        """
    def get_text(self, by: str, element: str, name: str = ...) -> str:
        """
        Get the element text
        Parameters
        ----------
        name:       Specific the element name for pretty logging

        Returns
        -------
        str:        The text of element
        """
    def wait_element(self, by: str, element: str, timeout: int, name: str = ...) -> WebElement:
        """
        Wait until the element present, then return the element
        Parameters
        ----------
        timeout:    wait time
        name:       Specific the element name for pretty logging

        Returns
        -------
        WebElement: element found success     /    None:   timeout, no element found, exception
        """
    def is_clickable(self, by: str, element: str, timeout: int, name: str = ...) -> bool:
        """
        Wait until the element is clickable, then return True
        Parameters
        ----------
        timeout:    wait time
        name:       Specific the element name for pretty logging

        Returns
        -------
        True / None
        """
    def is_displayed(self, by: str, element: str, timeout: int, name: str = ...) -> bool:
        """
        Wait until the element displayed, then click the element immediately
        Parameters
        ----------
        timeout:    wait time
        name:       Specific the element name for pretty logging

        Returns
        -------
        True:       element is displayed
        None:       element not found
        """
    def click_until(self, by: str, element: str, timeout: int = ..., name: str = ...) -> bool:
        """
        Wait until the element displayed, then click the element immediately
        Parameters
        ----------
        by
        element
        timeout:    wait time
        name:       Specific the element name for pretty logging

        Returns
        -------
        True:       click element success
        None:       element not found
        """
    def send_until(self, by: str, element: str, value: str, timeout: int = ..., name: str = ...) -> bool:
        """
        Wait until the element displayed, then send the characters immediately
        Parameters
        ----------
        value:      The characters to be sent
        timeout:    Time to wait the element found
        name:       Specific the element name for pretty logging

        Returns
        -------
        True:       send value to element success
        None:       element not found
        """
    def select_option(self, by: str, element: str, select_by: str, option: str, name: str = ...) -> bool:
        """
        Choose one option from html select element
        Parameters
        ----------
        select_by:  Select by type, choose from [index, value, text]
        option:     Option to be selected
        name:       Specific the element name for pretty logging

        Returns
        -------
        True:       select the option success
        None:       element not found
        """
    def js_click(self, by: str, element: str, name: str = ...) -> bool:
        """
        Use JavaScripts to click element in some special case
        Parameters
        ----------
        name:       Specific the element name for pretty logging

        Returns
        -------
        True:       click the option success
        None:       element not found
        """
    def wait_alert(self, timeout: int) -> Alert:
        """
        Wait the html alert message
        Parameters
        ----------
        timeout:    time to wait

        Returns
        -------
        Alert:      html alert found    /    None: No Alert present after wait timeout
        """
    def alert_handle(self, accept: bool, timeout: int, text: str = ...) -> bool:
        """
        Wait alert with specific text present. if present, accept or dismiss
        Parameters
        ----------
        accept:     True -> accept  /   False -> dismiss
        timeout:    time to wait
        text:       Alert text, if not set, try to handle any alert pop out.

        Returns
        -------
        True:       No alert exists / Alert is handled
        """
    def switch_page_name(self, name: str) -> bool:
        """
        Switch and active the specific page name
        Parameters
        ----------
        name:       page name (regular match)

        Returns
        -------
        True:       switch to page success
        None:       switch to page exception
        """
    def switch_page_index(self, index: int) -> bool:
        """
        Switch and active the specific page index
        Parameters
        ----------
        index:       page index (start from 0, -1 means last open page)

        Returns
        -------
        True:       switch to page success
        None:       switch to page exception
        """
    def get_attribute_by_element(self, by: str, element: str, attribute: str, timeout: int, name: str = ...) -> str:
        """
        Wait element present, then get the element's specific attribute
        Parameters
        ----------
        attribute:      Element attribute name
        timeout:        Time to wait
        name:           Specific the element name for pretty logging

        Returns
        -------
        str:            Attribute value string
        """
    def save_element_by_attribute(self, by: str, element: str, attribute: str, save_file: str, name: str = ...) -> str:
        """
        Find element, then save the specific attribute to local
        Use for logo / static resource saving
        Parameters
        ----------
        attribute:      Element attribute name
        save_file:      Save file path
        name:           Specific the element name for pretty logging

        Returns
        -------
        str:            save file path
        None:           element or attribute not found
        """
    def screen_shot(self, filename: str, time_stamp: bool = ..., ext: str = ...) -> bool:
        """
        Screen capture for web browser
        Parameters
        ----------
        filename:       Capture image file name
        time_stamp:     If time_stamp is True, rename image file with timestamp
        ext:            Specific the image extension type

        Returns
        -------
        True:           Web Capture Screen success
        False:          Web Capture Screen failed
        """
    def close_page(self) -> bool:
        """
        Close the web page, if no page exists, close the web driver
        Returns
        -------

        True:           Close page success
        None:           Close page error
        """
    def quit_browser(self) -> bool:
        """
        Quit the browser and close all page
        Returns
        -------
        True:           Quit browser success
        None:           Quit browser error
        """

class ChromeDriver:
    VersionMatch: Any
    url_mirror: str
    url_driver: Any
    def __init__(self) -> None:
        """
        download chromedriver.exe from specific mirror url
        Parameters
        ----------
        self.url_mirror:    mirror url
        self.url_driver:    driver path (fit for different mirror url)
        """
    @staticmethod
    def chrome_version():
        """
        return version of chrome from windows regedit
        """
    def get_driver_url(self, full_ver):
        """
        Get the latest chromedriver version of current chrome
        Parameters
        ----------
        full_ver:       full version of chrome installed.   like: 98.0.4758.80

        Returns
        -------
        str:            return the url path for driver download
        """
    @staticmethod
    def unzip_package(src_file, dest_dir, password: Any | None = ...):
        """
        Unzip the zip file to specific folder
        Parameters
        ----------
        src_file:       source zip file
        dest_dir:       destination directory
        password:       zip file's password

        Returns
        -------
        Returns         the file path of chromedriver.exe after unzip
        """
    def get_chromedriver(self):
        """
        Read Chrome Browser version and download and unzip specific chromedriver.exe to user's downloads folder
        Returns
        -------
        str:    return the path of chromedriver.exe
        """
