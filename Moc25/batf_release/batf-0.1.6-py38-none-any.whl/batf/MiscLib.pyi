from typing import Union

def shell_cmd(cmd: str, encoding: str = ...):
    """
    Execute general shell command and return the response string and exit code.
    Parameters
    ----------
    cmd:  str
        cmd string to execute
    encoding: str
        response string encoding, default is "gbk"

    Returns
    -------
    object:         output:    response output string
                    error:     response error string
                    exitcode:  response exit code
                    result:    response result, if exit code = 0, return True, else False
    """
def ping_sut(ip: str, timeout: int = ..., encoding: str = ..., expect: str = ...) -> bool:
    """
    Ping the ip address until timeout, check whether SUT is online

    Parameters
    ----------
    ip: str
        IP address
    timeout: int
        if ping timeout, process will be break, default is 300s
    encoding: str
        cmd response encoding, default is "gbk"
    expect: str
        expect string if ip is online

    Returns
    -------
    True:   ip is connected
    False:  ip is not connected and ping timeout
    """
def verify_msgs_in_log(msg_list: list, captured_log: str):
    """
    Verify if all the messages list in the log,  with regex match

    Parameters
    ----------
    msg_list: list
        The list contains all the strings to be verified
    captured_log: str
        The log strings of captured

    Returns
    -------
    True:   All members in the msg_list in the capture_log
    False:  At least one of the members not in the capture_log
    """
def uncompress_targz(targz_file: str, uncom_path: str):
    """
    Extract all files in the tar.gz package to specific path

    Parameters
    ----------
    targz_file: str     The tar.gz file path.
    uncom_path  str     The path that files will be extract to.

    Returns
    -------
    str:        return the uncompress path if extract files success
    False:      return False if uncompress failed
    """
def compare_images(image1: str, image2: str, image_diff: str = ...) -> bool:
    """
    compare whether two images are the same.

    Parameters
    ----------
    image1 : str
        File path of the 1st image to be compared.
    image2 : str
        File path of the 2nd image to be compared.
    image_diff: str
        save the difference as a picture if not same

    Returns
    -------
    Bool
    return True if they are same, otherwise return false
    """
def same_values(item_a: list, item_b: list):
    """
    Check if two list object contains the same members and ignore the order

    Parameters
    ----------
    item_a: list    The 1st list to be checked
    item_b: list    The 2nd list to be checked

    Returns
    -------
    True:   The two list members are same
    False:  The two list members are different
    """
def regex_unescape(strs: str, chrs: str = ...) -> str:
    """
    字符串做非转义处理: 在正则敏感字符前加斜杠''。
    示例:  Intel(R) Xeon(R) Gold [8888]  =>  Intel\(R\) Xeon\(R\) Gold \[8888\]
    Parameters
    ----------
    strs:       需要处理的字符串
    chrs:       需要做非转义的字符,比如(). 若未指定，则默认为：$ ( ) * + ? [ ] \ ^ | . { }

    Returns
    -------
    str:        返回处理后的字符串
    """
def msg_contain(msg, words: Union[str, list], excepts: Union[str, list] = ...):
    """
    字符串应该排包含所有的words，同时排除excepts
    Parameters
    ----------
    msg             待检查字符串
    words           预期应该存在的字符串
    excepts         预期不应该出现的字符串，若出现则认为Fail，默认为None

    Returns
    -------
    bool            若预期存在的全部找到，预期不存在的未找到，则返回True
    """
def msg_exclude(msg: str, words: Union[str, list], ignores: Union[str, list] = ...):
    """
    字符串应该排除words，但忽略ignores
    示例： 串口日志中不应该存在"error"关键字，但忽略"error not found"字符串
    Parameters
    ----------
    msg:            待检查字符串
    words:          预期不应该存在的字符串
    ignores:        忽略列表：若某行包括非法字符串，但发现当前行在忽略列表中，则不算fail

    Returns
    -------
    bool            若每一行都未发现排除的字符串，或者发现了但忽略，则返回True
    """
def file_str_replace(file, pattern: str, replace: str) -> bool:
    """
    更新文件：打开一个文件，并将文件中的所有字符串替换，然后关闭文件

    Parameters
    ----------
    file:       文件路径
    pattern:    查找的字符串，支持正则
    replace:    替换的字符串

    Returns
    -------
    bool:       若修改成功返回True
    """
def value_close(value: Union[int, float], base: Union[int, float], percentage: Union[int, float] = ...) -> bool:
    """
    检查当前值value是在base的±百分比范围内，默认为±5%
    Parameters
    ----------
    value:          待检查的值
    base:           基础值
    percentage:     百分比范围

    Returns
    -------
    bool:           若在范围内返回True，否则返回False
    """
def time_str_offset(from_time: str, to_time: str, from_type: str = ..., to_type: str = ...) -> int:
    """
    计算2个时间戳的时间差
    Parameters
    ----------
    from_time:      起始时间戳
    to_time:        结束时间戳
    from_type:      起始时间戳的格式，默认为 %Y-%m-%d %H:%M:%S
    to_type:        结束时间戳的格式，默认为 %Y-%m-%d %H:%M:%S

    Returns
    -------
    int:            返回 "to时间-from时间"之差，如果>0, 说明to时间比from时间晚
    """
def date_time_delta(time_str, days: int = ..., hours: int = ..., minutes: int = ..., seconds: int = ..., offset: str = ..., time_format: str = ...) -> str:
    """
    查找以某个日期时间点为基准，往前或者往后推N(天，小时，分钟，秒)的具体时间戳
    给定一个日期时间time_str, 以time_str为基准,往前或者往后推N个时间单位
    Parameters
    ----------
    time_str        基准时间戳
    days            N 天
    hours           N 小时
    minutes         N 分钟
    seconds         N 秒
    offset          "+":    往后加上N天
                    "-":    往前减掉N天
    time_format     时间戳的格式，默认为 %Y-%m-%d %H:%M:%S

    Returns
    -------
    str             返回经过计算后的时间戳
    """
