from typing import Any

class Key:
    ENTER: str
    DEL: str
    ESC: str
    UP: str
    DOWN: str
    RIGHT: str
    LEFT: str
    CTRL_ALT_DELETE: str

class Color:
    NORMAL: int
    BRIGHT: int
    REVERSED: int
    fBLACK: int
    fRED: int
    fGREEN: int
    fYELLOW: int
    fBLUE: int
    fMAGENTA: int
    fCYAN: int
    fWHITE: int
    bBLACK: int
    bRED: int
    bGREEN: int
    bYELLOW: int
    bBLUE: int
    bMAGENTA: int
    bCYAN: int
    bWHITE: int

class TermParser:
    Cursor: str
    COLOR_A: str
    COLOR_B: str
    color_template: Any
    option_selected: Any
    option_default: Any
    value_selected: Any
    value_default: Any
    grey_out: Any
    option_columns: Any
    value_columns: Any
    help_columns: Any
    body_columns: Any
    header_rows: Any
    body_rows: Any
    footer_rows: Any
    current: Any
    def __init__(self) -> None: ...
    key: Any
    def set_keymap(self, key) -> None: ...
    def set_cursor(self, option_columns: tuple = ..., value_columns: tuple = ..., help_columns: tuple = ..., header_rows: tuple = ..., body_rows: tuple = ..., footer_rows: tuple = ...): ...
    def set_color(self, option_selected: tuple, option_default: tuple, value_selected: tuple, value_default: tuple, grey_out: tuple): ...
    def drop_style(self, strs, cursor: bool = ..., color: bool = ..., whitespace: bool = ..., *args): ...
    def option(self, strs, span: int = ...): ...
    def grey_option(self, strs) -> dict: ...
