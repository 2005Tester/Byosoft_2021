from batf import SerialTerm
from batf.Common import RedfishLib, SutSerial, Unitool, ssh
from typing import Any, Union

class _GlobalCfg:
    ver: str

class Sut:
    BIOS_COM: Union[SutSerial.SutControl, SerialTerm.SerialTerm]
    BMC_COM: SutSerial
    BMC_SSH: ssh.SshConnection
    BMC_SFTP: ssh.sftp
    BMC_RFISH: RedfishLib.Redfish
    OS_SSH: ssh.SshConnection
    OS_SFTP: ssh.sftp
    OS_LEGACY_SSH: ssh.SshConnection
    OS_LEGACY_SFTP: ssh.sftp
    UNITOOL: Unitool.SshUnitool
    UNITOOL_LEGACY_OS: Unitool.SshUnitool

class ProjectInit:
    cli: Any
    prjcfg_file: str
    project_list: Any
    def __init__(self, cliparser) -> None: ...
    def load_project(self): ...

class SutInit:
    sut: Any
    resources: Any
    def __init__(self, project, resources) -> None: ...
