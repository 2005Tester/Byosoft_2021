from typing import Any

class Gitlab:
    projectid: Any
    access_token: Any
    base_url: str
    header: Any
    jobs_url: Any
    def __init__(self, projectid, access_token) -> None:
        """
        """
    def get_all_jobs(self):
        """
        """
    def get_latest_job(self, branch, jobname: Any | None = ...):
        """
        """
    @staticmethod
    def print_msg(job) -> None:
        """
        """
    def download_image(self, job, dir, img_name):
        """
        """
    def download_latest_image_master(self, dir, img_name):
        """
        """
    def download_latest_image(self, branch, dir, img_name, jobname: Any | None = ...):
        """
        """
    @staticmethod
    def unzip(artifacts, dst, img_name):
        """
        """
