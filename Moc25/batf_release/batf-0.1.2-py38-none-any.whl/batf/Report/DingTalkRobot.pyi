from typing import Any

class DingTalkRobot:
    report: Any
    sign: Any
    base_url: Any
    def __init__(self, base_url, url_report, signature) -> None:
        """
        """
    def gen_url(self):
        """
        """
    def send_msg(self, tittle, description) -> None:
        """
        """
