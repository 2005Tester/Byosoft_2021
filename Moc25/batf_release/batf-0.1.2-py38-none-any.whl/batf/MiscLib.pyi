def ping_sut(ip, timeout): ...
def verify_msgs_in_log(msg_list, captured_log): ...
def uncompress_targz(targz_file, uncom_path): ...
def compare_images(image1: str, image2: str, image_diff: str = ...) -> bool:
    """
    compare whether two images are the same.

    Parameters
    ----------
    image1 : str
        File path of the 1st image to be compared.
    image2 : str
        File path of the 2nd image to be compared.
    image_diff: str
        save the difference as a picture if not same


    Returns
    -------
    Bool
    return True if they are same, otherwise return false
    """
def same_values(item_a, item_b): ...
