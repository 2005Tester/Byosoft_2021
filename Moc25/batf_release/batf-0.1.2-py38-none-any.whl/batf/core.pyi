from typing import Any, List

class Status:
    Pass: int
    Skip: int
    Fail: Any

def test_case(tc: tuple) -> None:
    """
    装饰器, 用于标识测试用例.
    """
def capture_screen(img_dir: Any | None = ..., img_file: Any | None = ...) -> None:
    """
    Capture screen when needed, will try to call BMCLib to capture SUT KVM, if failed host based screen
    capture will be invoked. Captured image will be saved in test log directory by default.
    To Enable Screen capture by BMC, method capture_kvm_screen(dir, filename) must be implimented in
    BaseLib.BmcLib, expect return True if image is captured successfully.
    """
def stylelog(text: str, type: str) -> None:
    """
    Add clored style in logging message of html report, to highlight some checkpoints in test.

    Parameters
    ----------
    text : str
        Message to be highlighted.
    type : str
        Type of the message, 4 types are supported, 'fail', 'success', 'warning', 'info'.
        fail: show red text in html report.
        success: show green text in html report.
        warning: show yellow text in html report.
        info: show blue text in html report.

    Returns
    -------
    None
    """
def dump_acpi(ssh_obj: object, tables: list = ..., dst: str = ...) -> List:
    """
    Dump ACPI table in linux via ssh connection, root access is required, will generate acpi files in SUT's home directory
    of the account used for ssh access.

    Parameters
    ----------
    ssh_obj : str  
        Object of ssh connection, for example: Sut.OS_SSH

    tables : list
        Spefify acpi tables to be dummped, for example: ['DSDT', 'SSDT']. If not specified, will dump all the tables.

    dst : str
        Target directory (on host machine) of the dummped acpi txt files. Default is none, will not generate dump files.


    Returns
    -------
    Dict: 
        A dictionary with ACPI table data in below format {'SSDT': data, 'DSDT': data, .....}
    """
def dump_and_verify(ssh: object, command: str, dump_log_dir: str, expected_log: str) -> bool:
    """
    通过ssh执行命令, 比较返回的结果和预期结果.
    command执行结果会生成到本地dump_log_dir, 无需指定文件名, 如command="dmidecode -t 1", 会生成dmidecode_t_1.txt, 
    逐行比较实际结果和预期结果expected_log, 无差异则返回True, 否则返回False. 

    Parameters
    ----------
    ssh : object  
        Object of ssh connection, for example: Sut.OS_SSH

    command : str
        Spefified command to execute, for example: "dmidecode -t 1".

    dump_log_dir : str
        Target directory (on host machine) of the dummped log.
    
    expected_log : str
        Path of the expected log. 


    Returns
    -------
    bool: 
        Return true if no difference between actual and expected log, else return false.
    """
